club = "CoderDojo Kilkenny"

import sys
from cdkk.cdkkUtils import *
from cdkk.cdkkColours import *
from cdkk.cdkkSprite import *
from cdkk.cdkkSpriteExtra import *
from cdkk.cdkkPyGameApp import *
